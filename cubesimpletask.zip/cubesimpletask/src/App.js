import './App.css';
import { useState } from 'react';



function App() {
  const [userData,setEditdata] = useState([
    {
      id: 1,
      name:"ABC",
      email: 'abc@gmail.com',
      address:'chennai'
    },
    {
      id: 2,
      name:"DEF",
      email: 'def@gmail.com',
      address:'Madurai'
    }
  ]);
  const [isDisable, setIsDisable] = useState(true);
  const editName = (value,item) => {
    console.log(value);
    console.log(item);
    let temp = [...userData];
    let mapData = temp.map((ele,id) => {
      if(item.id == ele.id){
        ele.name = value
      }
      return ele;
    });
    setEditdata(mapData)
    console.log(mapData);
  }

  const editEmail = (value,item) => {
    console.log(value);
    console.log(item);
    let temp = [...userData];
    let mapData = temp.map((ele,id) => {
      if(item.id == ele.id){
        ele.email = value
      }
      return ele;
    });
    setEditdata(mapData)
    console.log(mapData);
  }

  const editAddress = (value,item) => {
    console.log(value);
    console.log(item);
    let temp = [...userData];
    let mapData = temp.map((ele,id) => {
      if(item.id == ele.id){
        ele.address = value
      }
      return ele;
    });
    setEditdata(mapData)
    console.log(mapData);
  }
  return (
    <div style={{display: 'flex',justifyContent:'center',alignItems:'center'}}>
      <div style={{display: 'flex',flex:1,border: '1px solid',flexDirection:'column'}}>
        <div style={{display: 'flex',flex:0.1,border: '1px solid #727272',justifyContent:'space-between'}}>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:1}}>
            <h6>ID</h6>
          </div>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:2}}>
            <h6>Name</h6>
          </div>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:3}}>
            <h6>Email</h6>
          </div>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:2}}>
            <h6>Address</h6>
          </div>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:2}}>
            <h6>Action</h6>
          </div>
        </div>
        
        <div style={{display: 'flex',flex:0.9,flexDirection:'column'}}>
          {
            userData.map((item) =>{
              return(
                <div key={item.id} style={{display: 'flex',flex:0.1,border: '1px solid #727272',justifyContent:'space-between'}}>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:1}}>
            <h6>{item.id}</h6>
          </div>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:2}}>
          <input type='text' disabled={isDisable} value={item.name} style={{margin:10}} onChange={(event) => {
              editName(event.target.value,item)
            }}></input>
          </div>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:3}}>
            <input type='text' disabled={isDisable} value={item.email} style={{margin:10}} onChange={(event) => {
              editEmail(event.target.value,item)
            }}></input>
          </div>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:2}}>
          <input type='text' disabled={isDisable} value={item.address} style={{margin:10}} onChange={(event) => {
              editAddress(event.target.value,item)
            }}></input>
          </div>
          <div style={{display:'flex', justifyContent:'center',alignItems:'center', border:'1px solid black',flex:2}}>
          <button style={{backgroundColor:"darkseagreen"}} onClick={() => {
              setIsDisable(false)
            }}>Edit</button>
            <button style={{margin:"5%",backgroundColor:"cadetblue"}} onClick={() => {
              console.log(item);
              let deleteData = userData.filter((ele) => {
                if(item.id != ele.id){
                  return ele;
                }
              })
              console.log(deleteData);
              setEditdata(deleteData)
            }}>Delete</button>
          </div>
        </div>
              )
            })
          }
        </div>
      </div>
    </div>
  );
}

export default App;
